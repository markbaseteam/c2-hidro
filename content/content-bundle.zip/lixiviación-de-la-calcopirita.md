- CuFeS2 
- CuFeS2 + O2, Los productos serán primero que todo el Cu2+
	- El Cu2+ tendrá solamente un mol ya que CuFeS2 tiene un mol o un átomo de cobre
	- Se produce un Fe2+, donde pasa lo mismo, tiene un solo mol o átomo de cobre
	- En el caso del SO4 generado, son dos moles, ya que hay dos átomos o moles de Azufre en la calcopirita
	- En el caso del oxígeno, este es relevante solo cuando se tiene que balancear los coeficientes de la reacción química, ya que, el oxígeno en sí no es un producto, si no que un agente lixiviante
### Resultado
- CuFeS2 + 4O2 = Cu2+ + 2SO4 2- + Fe2+