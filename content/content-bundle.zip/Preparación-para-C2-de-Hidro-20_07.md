
#### Preguntas C2 de Hidrometalurgia

- 1.1 (12%) Seleccionar la o las alternativas correctas (con una “X” al lado derecho) (En el proceso de Lix de óxidos en Pilas – SX – EW, ¿dónde se genera ácido?:
a)    En EW
b)    En SX
c)     En la pila de lixiviación (X)

1.2   A qué corresponde el consumo de ácido neto en la Lix en pilas
a)    Al ácido consumido por los minerales de cobre
b)    Al consumo de ácido de la ganga
c)    Al consumo de ácido de los minerales de cobre más la ganga
d)    Ninguna de las anteriores

1.3          Se dice que un mineral de oro es refractario porque:
a)    Requiere altas temperaturas para su tratamiento
b)    El oro hay que lixiviarlo en autoclave
c)    No es factible extraer el oro lixiviándolo con cianuro
d)    Resiste altas temperaturas (> 1200ºC)

1.4          La lixiviación de concentrados de cobre con el proceso CESL se caracteriza por ser:
a)    Un proceso de lix en autoclave de mediana temperatura, SI
b)    El azufre del concentrado se oxida a sulfato (sulfato de cobre y S elemental)
c)    El hierro del concentrado se fija como hematita. SI
d)    Se utiliza cloro como oxidante, NO
e)    Permite producir cátodos de cobre mediante SX – EW, NO


1.             (10%)Completar:

a) En la figura siguiente indique a que flujo corresponden el Refino, PLS e ILS (escribir en los recuadros en blanco).
![[Pasted image 20230716164947.png]]
	- El PLS va a SX, creo que el recuadro que está antes del [[SX]]
	- ILS debería ser el recuadro de arriba, ya que el ILS, la solución saliente de lixiviación se va nuevamente y retorna como ILS
	- La que sale de SX se transforma en refino y retorna a la LIX
- c) Describa en pocas palabras que es:
- Porqué en plantas de lixiviación en pilas se ha incorporado la etapa de lixiviación de los Ripios: 
- Qué tipo de mineral se trata en la lixiviación ROM: 
- Para qué sirve el análisis de Cu soluble de un mineral de cobre:

1.    (8%) A partir de la figura, responda:

a)     Nombre 3 elementos del diagrama que a pH 8 estaría totalmente precipitados:¿Qué hidróxido es más insoluble, el de Mn+2 o el del Mg+2?, justifique.

b)    Si tiene una solución 0.001 M de Ni2+ y 0.001 M de Cd2+ a pH 2. Hasta que eficiencia de precipitación de Ni se puede llegar sin que precipite el Cd (dibuje en el grafico para determinar los valores).

![[Pasted image 20230716165057.png]]

1.   (6%) A partir de la figura siguiente determine el rango de pH en que el H2 (1 atm) puede reducir a (marque en la figura como deduce la respuesta):
a.   al cobre cuando está en una concentración de 0.1 M :
b.   al cadmio cuando está en una concentración de 0.001 M: 
c.   al zinc cuando está en una concentración de 0.001 M:

![[Pasted image 20230716165131.png]]

#### Clases y Revisión de PPTS
- [[Lixiviación-de-sulfuros-de-cobre]]

### Ejercicios de Hidro para el certamen

- PROBLEMA 1

Un concentrado de cobre que contiene covelita y sílice se lixivia con una solución de sulfato férrico en medio ácido (H2SO4), obteniéndose sulfato de cobre soluble (CuSO4) y azufre elemental insoluble. La pulpa después se envía a una etapa de separación S/L que consta de un espesador y un filtro.

a)    Plantear la reacción de lixiviación

b)    El flujo de residuo sólido después de la lixiviación

c)     Calcular el flujo y concentración de cobre del PLS obtenido

d)    El flujo de PLS que sale por el rebalse del espesador

e)    El flujo de solución fuerte del filtro

f)      El flujo y concentración de cobre de la solución de lavado del filtro

g)    La eficiencia de recuperación de cobre del espesador + filtro

|   |   |   |   |   |   |
|---|---|---|---|---|---|
|Concentrado (t/h)|   |12||Filtro||
|%Sólidos c/r sólido inicial|   |6||%humedad queque|10|
||%Cu|45||Efic lavado / lavado|50|
|%Extr de Cu en lix|   |98||Nº lavados|2|
|Dens. PLS (kg/L)|   |1.0||Dens. soluc. lavado|1|
|%Sólid. Desc. Espesador|   |45||PA: Cu 63.5; S 32, O 16|   |
|||||||

PROBLEMA 2

Se realizó una prueba de lixiviación en columna de un mineral oxidado de cobre. Se aplicó un riego durante 4 días y en el 2do día comenzó a salir solución por la parte inferior de la columna (rompimiento) y se tomó una muestra del volumen acumulado en el día que se envió a análisis químico por Cu y H2SO4. Luego se tomaron muestras del volumen acumulado cada 24 horas que también se enviaron a análisis. Después de los días de riego se dejó drenar por tres días. En la tabla siguiente se entrega la información.

|   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|
|%Cu T||0,80||Dia|PLS, L|H2SO4, g/L|Cu, gpl|
|%Cu soluble|   |0,70||1||||
|Diámetro columna, cm|   |25||2|6|1,5|22,0|
|Alturo columna, m|   |1,8||3|10|2,5|18,0|
|Densidad aparente, kg/L|   |1,6||4|11|3,5|14,0|
|Tasa riego (L/ h m2)|   |10||5|11|4,5|12,0|
|Cu en soluc lix. (g/L)|   |0||6|10|6,0|7,0|
|H2SO4 en soluc. Lix, g/L|   |15||7|7|7,0|3,5|
|Curado (kg/t)|   |6||8|5|8,0|1,5|
|Días de riego|   |6||||||

a)    Calcular la recuperación de cobre al final de la prueba con respecto al Cu total

b)    Calcular el consumo de ácido en kg/t de mineral y en kg/kg de Cu al final de la prueba

c)     El mineral contiene 5% de Fe y el 4% de este Fe pasa al PLS. Si el PLS fuera parte de un circuito cerrado Lix-SX y la concentración de Fe en el PLS no puede superar los 20 g/L, calcule el volumen de purga para eliminar el Fe. Suponer que no hay pérdidas de solución por otras vías.

d)    Si se asume que en SX se extrae el 100% del cobre, calcular el consumo de ácido neto

#### Otros Certámenes
- [[C2-de-Hidro-2019]]
- [[Clase-de-Hidro-13_06]]
- [[Clase-de-Hidro-20_06]]
- [[Clase-de-Hidro-29_06]]