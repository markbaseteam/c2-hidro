- Es:
$$Cu_2S + 2Fe^{3+} = CuS + Cu^{2+} + 2Fe^{2+}$$
- se descompone en covelina y a la vez en Cu2+ que se disuelve
- el agente lixiviante es el Férrico
- Este, pasa a ferroso, que es un estado de oxidación de 2+
- Luego, se deben de balancear los átomos, tiene que sumar 6, el 3+ típicamente que se le multiplica por 2 y como el Cu2+ del lado derecho ya está listo, entonces, se multiplica por 2 tanto al Fe3+ como al Fe2+ y con eso quedaría todo balanceado!