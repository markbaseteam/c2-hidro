### Cristalización
- [[Proceso-de-la-Cristalización]]
- El test es el 26 de JUNIO, podría ser el MARTES 27 en horario de la tarde
- Pero parece que se va a cambiar
- [[Clase-de-Hidro-20_06]]
- [[Preparación-T2-de-Hidro]]

### Separación Sólido-Líquido
- Es la extracción, recuperación y la purificación de los metales en procesos de medio acuoso
- Los metales son recuperados a la forma de óxidos, hidróxidos u otro compuesto
- El [[tratamiento-hidrometalúrgico]] también es aplicado a otros compuestos
- Otros tratamientos hidro son la [[Lixiviación]] y la [[Recuperación-del-metal]]

### Relacionado
- [[Ejercicio-de-Lixiviación-en-Columna]]