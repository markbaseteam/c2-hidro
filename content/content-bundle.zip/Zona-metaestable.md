- Si se agregan pequeñas semillas de la misma sal, es como si fueran semillas, y se produce el crecimiento de esos cristales
- Si no hay cristales, no se hace la cristalización espontánea
	- En donde sí se hace cristlización espontánea, es en la zona inestable y se le conoce como la autonucleación
- Se aplica este tipo de cristalización solamente cuando se evapora el agua que es la sobresaturación por eliminación de agua
- Al agitar el sistema, afecta la [[Curva-de-supersolubilidad]] del sistema y se dispersan los cristales por medio de la solución

### Comentario de profe
- Al agregar semilla solamente se disolverá hasta alcanzar la saturación, si la solución está saturada, entonces no se disolverá la sal semilla [[Zona-estable]]