$$CuS + 2Fe^{3+} = Cu^{2+} + S^0 + 2Fe^{2+}$$
- Entonces, es lo mismo, solo que forma el azufre elemental