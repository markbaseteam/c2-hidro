- Tienes el detalle de que vuelves a generar tanto el férrico ya que el Fe2+ se airea y en medio ácido, forma al Ferroso, que es el agente lixiviante en la lix en autoclave tanto en el proceso de 100a 118 °C, que era el sherritt gordon, como la lix con autoclave a 90°C
- La reacción es la siguiente: 
$$4Fe^{2+} + O_2 + 4H^+ = 4Fe^{3+} + 2H_2O
$$
