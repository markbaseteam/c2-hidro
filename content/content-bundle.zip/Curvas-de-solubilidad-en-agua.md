- Es una propiedad del sistema soluto-solvente
- La curva de supersolubilidad depende de otros factores como la velocidad de enfriamiento, agitación, presencia de partículas
- [[Zona-metaestable]]
- [[Zona-estable]]
- [[Zona-inestable]]

- [[Parámetros-de-enfriamiento-y-concentración]]