1. [[Cristalizadores de Enfriamiento]]
2. [[Cristalizadores de evaporación]]
3. [[Cristalizadores de vacío]]
- 