---
quickshare-date: 2023-06-26 22:26:38
quickshare-url: "https://noteshare.space/note/cljdo7sjk1547801pjlthojcn8#wA17x6BsHJWONDL2jVLEVROvzQAUpuetJt6Xq+ov9qs"
---
### T2 de Hidrometalurgia 2022-1
- Teoría 1. Responder V o F (21%): 
- _F__ En un [[circuito DCC]], uno de los objetivos es aumentar el porcentaje de sólido de la pulpa 
	- Esta pregunta es falsa, pero, no estoy seguro porqué
- _V__ En un [[circuito DCC, al aumentar la razón de lavado]] aumenta la recuperación del metal contenido en el PLS 
	- Quiere decir de que cuando se aumenta el caudal de lavado en comparación con el caudal en la descarga, entonces, la recuperación de metal contenido en el PLS es mayor, esto, en [[Agua de lavado]] de la flotación, arrastra la ganga hidrofílica, entonces, puede decirse de que el agua de lavado arrastra la ganga? o va arrastrando el sólido como ganga, al tener el PLS como salida y el residuo sólido, como esa es la "ganga del proceso" entonces, puede decirse con certeza de que se elimina el residuo sólido
- _V__ La jarosita es un compuesto utilizado para el abatimiento del hierro. [[precipitación-de-sulfato-de-hierro-con-jarosita]]
- _V__ En la zona metaestable del diagrama de solubilidad de una sal, no hay cristalización espontánea 
- La sobresaturación de una sal para producir la cristalización, se puede lograr mediante 
	- _V__ Adición de un ion común [[Cristalización-por-ión-común]]
	- _F__ Agregando semilla de la misma sal , solamente es factible en la [[Zona-metaestable]], (La sobresaturación es la zona estable)
	- _F__ Aplicando vacío 
- [[Curva-de-solubilidad]]
- [[Curva-de-supersolubilidad]]
 1. De acuerdo al diagrama de precipitación de hidróxidos, responder: (14%) 
	 a) Nombrar 3 elementos que a pH 4 están completamente precipitados 
	 b) Si tiene una solución 0.01 M de Zn+2 y 0.001 M de Ni+2 a pH 4. Modificando el pH, que eficiencia de precipitación de Zn se puede obtener sin que precipite el Ni (mostrar en el gráfico) 
	 
	 Problema 1 (40%) En una planta de lixiviación agitada se obtienen 120 TPH de una pulpa al 12% en sólidos que contiene un PLS con 14 g/L de Cu. La pulpa se envía a un espesador donde se obtiene una descarga con 55% en sólidos. La pulpa de 55% en sólidos se envía a un circuito de lavado en contracorriente con 2 espesadores utilizando agua con una RL de 4. (Considerar densidad líquido = 1 kg/L) 
	 
	 a) Determinar caudal de PLS de la pulpa que se alimenta al circuito DCC (QL) y rebalse E1 
	 b) Mediante balance de masa determinar flujos y concentraciones de Cu en cada uno de los espesadores del circuito DCC 
	 c) Determinar eficiencia del circuito DCC 
	 d) Recuperación global de Cu (Espesamiento + circuito DCC) 
	 
	 
	 Problema 2 (25%) Se tienen 10 m3 una salmuera que contiene 120 g sal/100 g H2O a 80ºC. Se evaporan 2500 kg de H2O y la salmuera se enfría a 15ºC. La solubilidad a esta temperatura es de 35 g/100 g de H2O. Densidad de la salmuera: 1.08 kg/L 
	 a) Calcular la composición en peso de la salmuera inicial. 
	 b) Calcular la masa de sal cristalizada (anhidra).



### T2 de Hidrometalurgia 2022-2
- Teoría 1. Responder V o F (16%): 
- a) Si se tiene una pulpa de lixiviación de concentrado de cobre con 5% en sólidos que debe tratarse en un circuito DCC, qué opción escogería y porqué? 
	- i) La pulpa se pasa por un primer espesador para obtener una descarga con 50% en sólidos y luego se envía al circuito DCC de 3 etapas (ESTA OPCIÓN ES CORRECTA)
	- ii) La pulpa se envía directamente a un circuito DCC con 3 etapas (Esto haría de que los equipos de DCC deberían ser de mayor tamaño y tener un volumen de pulpa mayor que hay que lavar)
		- Supongo que hay que usar mayor agua de lavado con esta opción no?
- [[Escoger-tratamiento-de-circuitos-DCC]]
- b) Responda V o F e justifique. La sobresaturación de una sal para producir la cristalización, se puede lograr mediante 
	- _V__ Adición de un ion común, ya que el kps es mayor al kps original,
	- _F__ Agregando semilla de la misma sal 

 2. De acuerdo al diagrama de precipitación de hidróxidos, responder: (14%) 
 - a) Que elemento forma un hidróxido más insoluble, el Al+3 o el Fe+2?, justifique. 
	 - Escomo obvio que el hidróxido que va a hidrolizar valga la redundancia, o que es más insoluble, es el que tenderá a precipitar a los pH más bajos, esto, se ve para el caso de Al^3+ ya que es un metal divalente con un mayor número de valencia
	 - Por ende, el Fe2+ es el metal más soluble, o se hidroliza con mayor solubilidad
 - b) Si tiene una solución 0.01 M de Fe+2 y 0.001 M de Mn+2 a pH 3. Modificando el pH, cómo podría separarlos? Y con que eficiencia? (mostrar en el gráfico)
	 - Se tiene de que el Fe2+ precipita a pH de 8 a 10 aproximadamente sin que precipite el Mn2+ entonces el Fe2+ final es 
	 - La eficienia de sepearción se calcula como inicial-final/inicial x 100
- La imagen es la siguiente:
![[Pasted image 20230627143630.png]]
- [[Nombrar-3-elementos-del-diagrama-que-estén-completamente-precipitados-a-pH-4]]
- [[Qué-quiere-decir-con-la-eficiencia-de-precipitación]]
2. A partir de la misma figura, responde:
a) Se tiene una solución de 0.001 M de Zn2+ indique si a pH 7 y pH 9 se encuentra precipitado o es estable en solución
b) Si tiene una solución 0.01 M de Be2+ y 0.01  M de Cu2+ a pH 2. Modificando el pH hasta qué concentración de Be se puede llegar sin que precipite el Cu (mostrar en el gráfico)
  
 Problema 1 (35%) Se lixivia un mineral de oro en un sistema agitado y la pulpa resultante se envía un circuito DCC con 2 espesadores en contracorriente. Calcular: 
	 
- Mineral de Au, TPD 175 
- Densidad del liquido inic. (g/mL) 1,0 
- Au, ppm 4,9 
- Dens liquido final (g/mL) 1,0 
- %Extraccion de Au 97 
- RL (razon de lavado circuito DCC) 3 
- %Solidos LIX 52 Cw (conc. Au en agua de lavado) 0 %Disolución solido Suponer = 0 
- a) el caudal de PLS obtenido (QL) y la concentración de oro en el PLS (CL) (densidad PLS = 1 g/cm3 ) 
- b) las concentraciones de Au en las soluciones en ambos espesadores 
- c) calcular la recuperación de oro en el circuito DCC 


- Problema 2 (35%) Se tiene una solución con 95 g de FeSO4/100 g de H2O a 80ªC y se desea cristalizar sulfato de hierro (II) heptahidratado (FeSO4 x 7H2O). Esta solución se somete a un proceso de cristalización por evaporación y enfriamiento. En este proceso se evaporan 75 kg de agua por m3 de solución y se enfría hasta 12ºC. Si la solubilidad a esta temperatura es de 7.2 g de FeSO4/100 g H2O , calcular: 
- a) Composición en peso de la solución (FeSO4 y H2O) 
- b) La masa de sal cristalizada para 1 m3 de solución 
- c) Concentración final de Fe en g/L 
	- Densidad solución inicial: 1.25 g/cm3 
	- Densidad solución final: 1.07 g/cm3 
	- PA: Fe 55.8, S 32, O 16

### Otras preguntas:
- **1.**       Circuitos de lavado en contracorriente (DCC)

**a)**      ¿Qué función cumplen?

**b)**      ¿Es aplicable a la Lix en pilas?, justifique.

**2.**       Abatimiento de hierro desde soluciones de lixiviación

**a)**      Menciones 3 compuestos de hierro utilizados para el abatimiento de hierro desde soluciones de lixiviación.

**b)**      ¿Cuál o cuáles de ellos requieren una operación en un reactor autoclave para obtenerlo?.

**c)**       De qué forma se elimina el hierro desde las soluciones de Lix en pilas de minerales de cobre.

**3.**       Se tiene una solución a 80ºC con 20 g/100 g de H2O de una sal y se sobresatura por evaporación hasta llegar a una concentración de la sal de 80 g/100 g de H2O. Luego se enfría hasta 40ºC. La densidad de la solución es de 1.15 kg/L y su solubilidad se rige de acuerdo a la gráfica.

**a)**      ¿Cuánta agua se evaporó por m3 de la solución?

**b)**      ¿Cuánta sal cristaliza por m3 de solución?



### Ayudantía de Hidro - Bastián Grez
- Se desea cristalizar sulfato de cobre pentahidratado desde una solución saturada de 5000 kg de CuSO4 y se encuentra a 90°C. La solubilidad del sulfato de cobre a esta temperatura es de 110 kgCuSO4/100 kg de Agua. Esta solución se somete a un proceso de [[cristalización-por-evaporación]] y [[Cristalizadores de Enfriamiento]]. En este proceso se evaporan 1000kg de agua y se enfría hasta 15°C. Si la solubilidad a esta temperatura es de 30 kg de CuSO4/100 kg de H2O, calcular la masa de sal cristalizada.
- [[Ejercicio-de-Cristalización]]
- Tenemos dos datos, uno de la solubilidad a 90°C y otro de la solubilidad a 15°C
- Ambas, se deben de expresar en términos de gramos
- a 90°C, si hay 110g de CuSO4 cada 100 g de H2O, y hay 5000 kg de sal, entonces, kg de agua, 90°C?, 5000 kg sal x100 H2O / 110 kg CuSO4= 4545.45 kg de Agua a 90°C
- Debemos de realizar un [[balance-de-agua-y-sal-cristalización-hidro]]
- Agua evaporada= 1000 kg
- El agua inicial, es el agua a 90°C, 4545.45 kg de Agua

##### Ejercicio 2 
- Se desea cristalizar sulfato de cobalto hepta hidratado desde un flujo de solución de 12,500 L/h saturada en CoSO4 que se encuentra a 80°C con una concentración de cobalto de 211 g/L. Esta solución se somete a un proceso de cristalización por evaporación y enfriamiento. En este proceso se evaporan 3,500 kg de Agua y se enfría hasta 20°C. Si la solubilidad a esta temperatura es de 36.2 g CoSO4 / 100 g de Agua, calcular la masa de la sal cristalizada y la masa de la solución final, densidad de la solución = 1.35 kg/L

- H2O evaporada: 3,500 kg de Agua
- De qué sirve el [[flujo-de-solución-ejercicio-de-hidro]]?
- Se tiene una concentración inicial de cobalto de 211 g/L, esta al multiplicar por el flujo de solución, que es de 12,500 L/h de CoSO4 saturado, se puede determinar los g/h, a los que al pasar a kilos, se tiene kg/h. 
	- Este cálculo es 12,500 L/h x 211 g/L /1000= 2637.5 kg de Cobalto
- La masa molar del Cobalto, La masa molar del CoSO4 y la masa molar del CoSO4 x 7H2O = 
	- Masa molar del Co = 58.9 g/mol
	- CoSO4 x 7H2O =280.96 g/mol
- [[cálculo-de-la-masa-de-cobalto-y-kg-de-H2O]]
	- 16,875 kg/h - 2637.5 kg/h  = 14,237.5 kg/h de H2O
	- Me equivoqué con esto, ya que este es el error típico de masa de solución - masa de Co, y es Masa de solución - Masa de CoSO4
- [[cálculo-de-masa-de-H2O-desde-CoSO4]]
- [[Concentración-inicial-de-CoSO4_sobre_H2O]]
- [[Cálculo-de-las-masas-de-H2O-inicial-y-COSO4-inicial]]
- La composición en la solución final es de 0.362 de CoSO4 y [[composición-de-agua-solución-final-letra-X]], y se multiplican junto con la X, corresponde a la composición final de la solución a 15°C
- Finalmente, tener la [[Cantidad-estequiométrica-de-y-para-las-dos-sustancias]]

### Ejercicio de espesadores contracorriente
- Una planta de lixiviación genera 200 TPH de pulpa de lixiviación de un mineral de cobalto con 6% en sóldio y la solución contiene 15 g/L de Co2+. La pulpa se envía a un primer espesador en donde se obitne un rebalse de 170 TPH de solución y la descarga se envía a un circuito de lavado en contracorriente con 2 espesadores usando agua a una RL de 4. Considerar denisdad pLS igual a 1 kg/L
a) Dibuje un esquema del circuito, - [[Dibujar-el-diagrama-de-un-circuito-DCC]]
b) Calcular el % de sóldios en la descarga del primer espesador, [[Cálculos-primer-espesador]], hay un 40% de sólidos en el primer espesador, listo.
c) Mediante un balance de masa determinar la concentración de Co en el líquido en cada uno de los espesadores del circuito DCC, [[Conservación-del-QL]], [[Cálculo-del-Qw]]
d) La recuperación global de cobre en el sistema DCC y en el circuito global de Espesamiento + DCC, [[Recuperación-de-un-DCC-recuperación-global]]

[[Procedimiento-Lab-de-Hidro-28_06]]
