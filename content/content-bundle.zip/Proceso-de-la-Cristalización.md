- Es el proceso físico de separar una sal a la forma de cristales
- Esto desde una [[solución acuosa y mediante la sobresaturación]]
- Los 3 pasos básicos que incluye un proceso de cristalización son:
1. Sobresaturación de la solución
2. [[Nucleación-de-Cristales]]
3. [[Crecimiento de cristales]]
- [[Cristalización-Proceso-Salar-de-Atacama]]
- [[Cristalización-por-ión-común]]
- [[Cristalización-por-adición-de-un-solvente]]
- [[Velocidad-de-nucleación-heterogénea]]
- [[Equipos-de-Cristalización]]
- [[Ejercicio-de-Cristalización]]

#### Ejemplo
- Cristalizar el CuSO4 x 5H2O
	- La primera parte de la molécula, por ejemplo para el CuSO4, este se le denomina "Anhidro"
- La solubilidad de esta sal se expresa en g de sulfato de cobre sin considera el agua sobre 100 g de Agua por ejemplo, 
- La solubilidad de las sales aumenta con la temperatura, salvo algunas como el [[Carbonato de Litio]]