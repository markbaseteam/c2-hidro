- Es la disolución de el o los metales provenientes de la mena
- Con un agente complejante o bien en medio ácido

### Recursos necesarios para la lixiviación
- Lo primero, es necesario de un agente de lixiviación
- Lo segundo, de un oxidante [[oxidantes baratos]]

### Relacionado
- [[Separación-sólido-líquido]]