- Últimamente, se ha utilizado la hidrometalurgia para el reciclaje de los materiales o de los metales
- El circuito de reciclaje es el siguiente, primero, el Manual Dismantling y luego la reducción de tamaño, [[Tablas-y-datos-Minería-secundaria]]
	- En la reducción de tamaño se ocupan las chancadoras y el molino de martillo
	- Los procesos pirometalúrgicos, requieren menos molienda que los procesos de separación física e hidrometalúrgicos (Principales-diferencias-entre-procesos-de-reciclaje)
	- La [[separación-física]] se lleva a cabo por Separación gravitacional, magnética, electroestátia, eddy-current separation, etc
	- Proceso pirometalurgia se ocupa la fundición, 
		- Fundición alto norte quiere implementar este proceso
			- Querían implementar 30 tpd al día en su proceso, procesan 1000 tpd de concentrado
		- La fundición tiene un problema ya que se contamina 
			- Hornos de fusión en europa son especiales para tratar este tipo de material
		- El proceso piro termina también con una EW
	- Hidrometalurgia, por [[Línea Hidro, Lixiviación-SX-EW]]
- El producto final obtenido es los base y los metales preciosos (Cu, Ag, Au, Pd)
- [[Agentes-lixiviantes-para-el-reciclaje]]
- Ventajas de ocupar la vía hidro
	- Con tantos elementos involucrados, tiene un menor costo de inversión, es más selectivo y es factible de implementar a pequeña escala
- Cu2S + O2 + H2SO4 = CuSO4 + 2H2O + S^0
	- Esta es una reacción química en el proceso de separación S/L
	- la concentración en 4,5 y 6 es la misma

[[Preparación-para-C2-de-Hidro-20_07]]
	
	